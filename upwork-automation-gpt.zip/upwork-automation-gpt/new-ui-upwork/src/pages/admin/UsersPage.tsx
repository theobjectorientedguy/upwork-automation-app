import UnderConstruction from "@/components/UnderConstruction";

const UsersPage = () => {
  return <UnderConstruction />;
};

export default UsersPage;