import UnderConstruction from "@/components/UnderConstruction";

const AdminDashboard = () => {
  return <UnderConstruction />;
};

export default AdminDashboard;