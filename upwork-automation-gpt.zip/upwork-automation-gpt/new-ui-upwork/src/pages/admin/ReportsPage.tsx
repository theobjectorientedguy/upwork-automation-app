import UnderConstruction from "@/components/UnderConstruction";

const ReportsPage = () => {
  return <UnderConstruction />;
};

export default ReportsPage;